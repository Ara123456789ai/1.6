package com.ascendant.sentiment

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.ui.platform.LocalContext
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ascendant.sentiment.engine.AstroEngine
import com.ascendant.sentiment.model.GeoLocation
import com.ascendant.sentiment.ui.*
import com.ascendant.sentiment.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {

    private fun triggerHaptic() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                @Suppress("DEPRECATION")
                vibrator?.vibrate(20)
            }
        } catch (_: Exception) {
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            AscendantSentimentTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = BgDark
                ) { innerPadding ->
                    MainScreen(
                        modifier = Modifier.padding(innerPadding),
                        onHaptic = { triggerHaptic() }
                    )
                }
            }
        }
    }
}


private fun alertTimeMs0(ms: Long): Long = (ms / 60_000L) * 60_000L

/** "  135° −2" : the aspect angle and the whole-degree distance to exact (negative approaching, positive leaving). */
private fun degText(d: Pair<Int, Int>?): String =
    if (d == null) "" else "   ${d.first}° " + (if (d.second < 0) "−${-d.second}" else if (d.second > 0) "+${d.second}" else "0")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    modifier: Modifier = Modifier,
    onHaptic: () -> Unit
) {
    var isLive by remember { mutableStateOf(true) }
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var centerTimeMs by remember { mutableLongStateOf((System.currentTimeMillis() / 60_000L) * 60_000L) }
    var inspectedTimeMs by remember { mutableLongStateOf((System.currentTimeMillis() / 60_000L) * 60_000L) }
    var selectedLocationIdx by remember { mutableIntStateOf(0) }
    var selectedTimezone by remember { mutableStateOf("Europe/London") }
    var zoom by remember { mutableStateOf(2f) }
    val ctx = LocalContext.current
    var trigDays by remember { mutableIntStateOf(3) }
    var showTrigger by remember { mutableStateOf(true) }
    var showHelioTint by remember { mutableStateOf(true) }
    var notifyOn by remember { mutableStateOf(AlertNotifier.isEnabled(ctx)) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        AlertNotifier.schedule(ctx)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    var showMarsAsp by remember { mutableStateOf(true) }
    var showSaturnAsp by remember { mutableStateOf(true) }
    var showPlutoAsp by remember { mutableStateOf(true) }
    var showPlutoWeek by remember { mutableStateOf(true) }
    var showMarsWeek by remember { mutableStateOf(true) }
    var showSaturnWeek by remember { mutableStateOf(true) }

    val locations = AstroEngine.PRESET_LOCATIONS
    val activeLocation = locations[selectedLocationIdx]
    LaunchedEffect(selectedLocationIdx) { AlertNotifier.saveLocation(ctx, activeLocation.lat, activeLocation.lon) }

    LaunchedEffect(isLive) {
        while (true) {
            val cur = System.currentTimeMillis()
            nowMs = cur
            if (isLive) {
                val snapped = (cur / 60_000L) * 60_000L
                centerTimeMs = snapped
                inspectedTimeMs = snapped
            }
            delay(1000)
        }
    }

    // 1-minute bars (361 of them) are computed off the main thread; the previous series stays on screen until the new one is ready
    val series by produceState<List<com.ascendant.sentiment.model.SentimentBar>>(emptyList(), centerTimeMs, activeLocation) {
        value = withContext(Dispatchers.Default) {
            AstroEngine.generateSeries(
                centerMs = centerTimeMs, windowHours = 6, lat = activeLocation.lat, lon = activeLocation.lon,
                orbLimit = 3.0, useSd = true, usePm = true, taintAllMm = true, orbFalloff = true, pairBoost = true, trigger = true
            )
        }
    }
    val chartView = remember(series) { intArrayOf(0, series.size, 1000) }
    val orbFalloff = true

    val weekBounds = remember(inspectedTimeMs / 86_400_000L, selectedTimezone) { AstroEngine.weekBoundsMs(inspectedTimeMs, selectedTimezone) }
    val trigBounds = remember(inspectedTimeMs / 86_400_000L, selectedTimezone, trigDays) {
        if (trigDays == 3) AstroEngine.weekBoundsMs(inspectedTimeMs, selectedTimezone, 1, 2)
        else AstroEngine.weekBoundsMs(inspectedTimeMs, selectedTimezone, 2, 5)
    }
    val trigData = remember(trigBounds.first, trigBounds.second, activeLocation, showTrigger) {
        if (showTrigger) AstroEngine.triggerCard(trigBounds.first, trigBounds.second, activeLocation.lat, activeLocation.lon) else null
    }
    val trigTrend = remember(trigBounds.first, trigBounds.second, showTrigger, showHelioTint) {
        if (showTrigger && showHelioTint) AstroEngine.helioTrendHourly(trigBounds.first, ((trigBounds.second - trigBounds.first) / 3_600_000L).toInt()) else null
    }
    val ticksMars = remember(series, activeLocation, showMarsAsp) {
        if (showMarsAsp && series.isNotEmpty()) AstroEngine.degreeTicks(series.first().timeMs, series.last().timeMs + 60_000L, activeLocation.lat, activeLocation.lon, "Mars") else null
    }
    val ticksSat = remember(series, activeLocation, showSaturnAsp) {
        if (showSaturnAsp && series.isNotEmpty()) AstroEngine.degreeTicks(series.first().timeMs, series.last().timeMs + 60_000L, activeLocation.lat, activeLocation.lon, "Saturn") else null
    }
    val ticksPlu = remember(series, activeLocation, showPlutoAsp) {
        if (showPlutoAsp && series.isNotEmpty()) AstroEngine.degreeTicks(series.first().timeMs, series.last().timeMs + 60_000L, activeLocation.lat, activeLocation.lon, "Pluto") else null
    }
    val degMarsNow = remember(alertTimeMs0(inspectedTimeMs), activeLocation, showMarsAsp) {
        if (showMarsAsp) AstroEngine.degreeNow(alertTimeMs0(inspectedTimeMs), activeLocation.lat, activeLocation.lon, "Mars") else null
    }
    val degSatNow = remember(alertTimeMs0(inspectedTimeMs), activeLocation, showSaturnAsp) {
        if (showSaturnAsp) AstroEngine.degreeNow(alertTimeMs0(inspectedTimeMs), activeLocation.lat, activeLocation.lon, "Saturn") else null
    }
    val degPluNow = remember(alertTimeMs0(inspectedTimeMs), activeLocation, showPlutoAsp) {
        if (showPlutoAsp) AstroEngine.degreeNow(alertTimeMs0(inspectedTimeMs), activeLocation.lat, activeLocation.lon, "Pluto") else null
    }
    val alertTimeMs = (inspectedTimeMs / 300_000L) * 300_000L
    val alertSat = remember(alertTimeMs, activeLocation) { AstroEngine.entryAlert(alertTimeMs, activeLocation.lat, activeLocation.lon, "Saturn") }
    val alertPlu = remember(alertTimeMs, activeLocation) { AstroEngine.entryAlert(alertTimeMs, activeLocation.lat, activeLocation.lon, "Pluto") }

    val moonPlutoMarks = remember(series, showPlutoAsp) { if (showPlutoAsp) AstroEngine.moonAspectMarks(series, "Pluto") else null }
    val moonMarsOwnMarks = remember(series, showMarsAsp) { if (showMarsAsp) AstroEngine.moonAspectMarks(series, "Mars") else null }
    val marsAsc = remember(series, showMarsAsp) { if (showMarsAsp) AstroEngine.planetAscendantSeries(series, orbFalloff, "Mars") else null }
    val marsGrid = remember(series, showMarsAsp) {
        if (showMarsAsp) AstroEngine.plutoActorGrid(series, target = "Mars", actorNames = AstroEngine.MARS_ACTOR_NAMES) else null
    }
    val marsWeek = remember(weekBounds.first, showMarsWeek) {
        if (showMarsWeek) AstroEngine.plutoActorWeek(weekBounds.first, target = "Mars", actorNames = AstroEngine.MARS_ACTOR_NAMES) else null
    }
    val marsExacts = remember(inspectedTimeMs / 3_600_000L, showMarsWeek) {
        if (showMarsWeek) AstroEngine.plutoExactInfo((inspectedTimeMs / 300_000L) * 300_000L, target = "Mars", actorNames = AstroEngine.MARS_ACTOR_NAMES) else emptyList()
    }
    val moonSatMarks = remember(series, showSaturnAsp) { if (showSaturnAsp) AstroEngine.moonAspectMarks(series, "Saturn") else null }
    val moonMarsMarks = remember(series, showPlutoAsp, showSaturnAsp) { if (showPlutoAsp || showSaturnAsp) AstroEngine.moonAspectMarks(series, "Mars") else null }
    val satAsc = remember(series, showSaturnAsp) { if (showSaturnAsp) AstroEngine.planetAscendantSeries(series, orbFalloff, "Saturn") else null }
    val plutoAsc = remember(series, showPlutoAsp) { if (showPlutoAsp) AstroEngine.planetAscendantSeries(series, orbFalloff, "Pluto") else null }
    val plutoGrid = remember(series, showPlutoAsp) { if (showPlutoAsp) AstroEngine.plutoActorGrid(series) else null }
    val saturnGrid = remember(series, showSaturnAsp) {
        if (showSaturnAsp) AstroEngine.plutoActorGrid(series, target = "Saturn", actorNames = AstroEngine.SATURN_ACTOR_NAMES) else null
    }
    val plutoWeek = remember(weekBounds.first, showPlutoWeek) { if (showPlutoWeek) AstroEngine.plutoActorWeek(weekBounds.first) else null }
    val plutoExacts = remember(inspectedTimeMs / 3_600_000L, showPlutoWeek) {
        if (showPlutoWeek) AstroEngine.plutoExactInfo((inspectedTimeMs / 300_000L) * 300_000L) else emptyList()
    }
    val saturnWeek = remember(weekBounds.first, showSaturnWeek) {
        if (showSaturnWeek) AstroEngine.plutoActorWeek(weekBounds.first, target = "Saturn", actorNames = AstroEngine.SATURN_ACTOR_NAMES) else null
    }
    val saturnExacts = remember(inspectedTimeMs / 3_600_000L, showSaturnWeek) {
        if (showSaturnWeek) AstroEngine.plutoExactInfo((inspectedTimeMs / 300_000L) * 300_000L, target = "Saturn", actorNames = AstroEngine.SATURN_ACTOR_NAMES) else emptyList()
    }

    val currentBar = remember(series, inspectedTimeMs) {
        if (series.isEmpty()) null
        else {
            val idx = ((inspectedTimeMs - series.first().timeMs) / 60_000.0).toInt().coerceIn(0, series.size - 1)
            series[idx]
        }
    }
    val curIdx = if (series.isEmpty()) 0 else ((inspectedTimeMs - series.first().timeMs) / 60_000L).toInt().coerceIn(0, series.size - 1)
    if (series.isNotEmpty()) updateChartView(chartView, series.size, zoom, curIdx)

    val liveSdf = remember(selectedTimezone) {
        SimpleDateFormat("EEE, dd MMM HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone(selectedTimezone) }
    }
    val jump: (Long) -> Unit = { t ->
        isLive = false
        if (series.isNotEmpty() && (t < series.first().timeMs || t > series.last().timeMs)) centerTimeMs = t
        inspectedTimeMs = t
    }

    Column(
        modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Pluto–Saturn", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Slate100)
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(color = Emerald500.copy(alpha = 0.2f), shape = RoundedCornerShape(4.dp)) {
                        Text("Brent CFD", color = Emerald400, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
                Text(
                    text = liveSdf.format(Date(nowMs)) + if (isLive) " · LIVE" else " · PAUSED",
                    fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = if (isLive) Emerald400 else Amber500
                )
            }
            Surface(
                color = CardDark, shape = RoundedCornerShape(8.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderDark))
            ) {
                Text("100% Offline Native", color = Slate400, fontSize = 10.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
            }
        }

        // Location, card switches, time steppers, Live and zoom
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardDark),
            shape = RoundedCornerShape(14.dp),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderDark))
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    locations.forEachIndexed { idx, loc ->
                        val isSelected = idx == selectedLocationIdx
                        Surface(
                            color = if (isSelected) Emerald500.copy(alpha = 0.2f) else Slate950,
                            shape = RoundedCornerShape(8.dp),
                            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(if (isSelected) Emerald400 else BorderDark)),
                            modifier = Modifier.clickable { onHaptic(); selectedLocationIdx = idx }
                        ) {
                            Text(
                                text = loc.name.split(" ").first(), fontSize = 11.sp,
                                color = if (isSelected) Emerald400 else Slate400,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ResonanceSwitch("Trigger card (lanes)", showTrigger, Modifier.weight(1f)) { onHaptic(); showTrigger = it }
                    ResonanceSwitch("Helio Sun tint", showHelioTint, Modifier.weight(1f)) { onHaptic(); showHelioTint = it }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ResonanceSwitch("Mars-only Asc pane", showMarsAsp, Modifier.weight(1f)) { onHaptic(); showMarsAsp = it }
                    ResonanceSwitch("Mars week card", showMarsWeek, Modifier.weight(1f)) { onHaptic(); showMarsWeek = it }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ResonanceSwitch("Saturn-only Asc pane", showSaturnAsp, Modifier.weight(1f)) { onHaptic(); showSaturnAsp = it }
                    ResonanceSwitch("Saturn week card", showSaturnWeek, Modifier.weight(1f)) { onHaptic(); showSaturnWeek = it }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ResonanceSwitch("Pluto-only Asc pane", showPlutoAsp, Modifier.weight(1f)) { onHaptic(); showPlutoAsp = it }
                    ResonanceSwitch("Pluto week card", showPlutoWeek, Modifier.weight(1f)) { onHaptic(); showPlutoWeek = it }
                }
            }
        }

        // Entry windows (next hour) with phone notifications
        AlertCard(
            saturn = alertSat,
            pluto = alertPlu,
            fromMs = alertTimeMs,
            timeZoneId = selectedTimezone,
            notifyOn = notifyOn,
            onNotifyChange = { onHaptic(); notifyOn = it; AlertNotifier.setEnabled(ctx, it) },
            onTest = { onHaptic(); AlertNotifier.sendTest(ctx) }
        )

        // Trigger card: Moon lanes, Ascendant lanes, hard aspects to the Moon (1-hour bars)
        if (showTrigger && trigData != null) {
            TriggerCard(
                data = trigData,
                trend = trigTrend,
                days = trigDays,
                inspectedTimeMs = inspectedTimeMs,
                nowMs = nowMs,
                timeZoneId = selectedTimezone,
                onDaysChange = { onHaptic(); trigDays = it },
                onDayStep = { d ->
                    onHaptic()
                    isLive = false
                    val newT = inspectedTimeMs + d * 86_400_000L
                    centerTimeMs = newT
                    inspectedTimeMs = newT
                },
                onInspectTime = jump
            )
        }

        // 1-minute panes
        if (series.isNotEmpty() && (showMarsAsp || showSaturnAsp || showPlutoAsp)) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardDark),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderDark))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("PANES · 1-MIN BARS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Slate100)
                    Spacer(modifier = Modifier.height(4.dp))
                    HelioLegend()
                    Text("Dots on the bars: the Moon aspects that planet (dot colour = that aspect, large dot = exact) · amber bar on top: two or more actors aspect that planet · vertical lines: full hours", color = Slate400, fontSize = 9.sp)

                if (showMarsAsp && marsAsc != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    val marsNow = currentBar?.aspects?.filter { it.planetName == "Mars" }?.minByOrNull { it.orbDiff }
                    val vMars = marsAsc.detr.getOrNull(curIdx)
                    PaneHeader(
                        title = "MARS ONLY · ASPECTS TO THE ASCENDANT  (detrended)",
                        value = (marsNow?.let { "♂ ${it.aspectAngle}°  " + (vMars?.let { v -> (if (v > 0) "+" else "") + "%.2f".format(v) } ?: "") } ?: "no Mars aspect") +
                            (moonMarsOwnMarks?.angle?.getOrNull(curIdx)?.takeIf { it >= 0 }?.let { "   ☽ $it° ♂" } ?: "") + degText(degMarsNow),
                        valueColor = marsNow?.let { HelioAspectColors[it.aspectAngle] } ?: Slate400
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))) {
                        SunAscendantPane(
                            data = marsAsc,
                            firstBarMs = series.first().timeMs,
                            inspectedTimeMs = currentBar?.timeMs ?: inspectedTimeMs,
                            view = chartView,
                            zoom = zoom,
                            marks = moonMarsOwnMarks,
                            bgMarks = null,
                            amber = marsGrid,
                            timeZoneId = selectedTimezone,
                            ticks = ticksMars,
                            modifier = Modifier.fillMaxWidth().height(124.dp)
                        )
                    }
                }
                if (showSaturnAsp && satAsc != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    val satNow = currentBar?.aspects?.filter { it.planetName == "Saturn" }?.minByOrNull { it.orbDiff }
                    val vSat = satAsc.detr.getOrNull(curIdx)
                    PaneHeader(
                        title = "SATURN ONLY · ASPECTS TO THE ASCENDANT  (detrended)",
                        value = (satNow?.let { "♄ ${it.aspectAngle}°  " + (vSat?.let { v -> (if (v > 0) "+" else "") + "%.2f".format(v) } ?: "") } ?: "no Saturn aspect") +
                            (moonSatMarks?.angle?.getOrNull(curIdx)?.takeIf { it >= 0 }?.let { "   ☽ $it° ♄" } ?: "") + degText(degSatNow),
                        valueColor = satNow?.let { HelioAspectColors[it.aspectAngle] } ?: Slate400
                    )
                    Text("Background tint: the Moon aspects Mars (tint colour = that aspect)", color = Slate400, fontSize = 9.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))) {
                        SunAscendantPane(
                            data = satAsc,
                            firstBarMs = series.first().timeMs,
                            inspectedTimeMs = currentBar?.timeMs ?: inspectedTimeMs,
                            view = chartView,
                            zoom = zoom,
                            marks = moonSatMarks,
                            bgMarks = moonMarsMarks,
                            amber = saturnGrid,
                            timeZoneId = selectedTimezone,
                            ticks = ticksSat,
                            modifier = Modifier.fillMaxWidth().height(124.dp)
                        )
                    }
                }
                if (showPlutoAsp && plutoAsc != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    val plutoNow = currentBar?.aspects?.filter { it.planetName == "Pluto" }?.minByOrNull { it.orbDiff }
                    val vPluto = plutoAsc.detr.getOrNull(curIdx)
                    PaneHeader(
                        title = "PLUTO ONLY · ASPECTS TO THE ASCENDANT  (detrended)",
                        value = (plutoNow?.let { "♇ ${it.aspectAngle}°  " + (vPluto?.let { v -> (if (v > 0) "+" else "") + "%.2f".format(v) } ?: "") } ?: "no Pluto aspect") +
                            (moonPlutoMarks?.angle?.getOrNull(curIdx)?.takeIf { it >= 0 }?.let { "   ☽ $it° ♇" } ?: "") + degText(degPluNow),
                        valueColor = plutoNow?.let { HelioAspectColors[it.aspectAngle] } ?: Slate400
                    )
                    Text("Background tint: the Moon aspects Mars (tint colour = that aspect)", color = Slate400, fontSize = 9.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))) {
                        SunAscendantPane(
                            data = plutoAsc,
                            firstBarMs = series.first().timeMs,
                            inspectedTimeMs = currentBar?.timeMs ?: inspectedTimeMs,
                            view = chartView,
                            zoom = zoom,
                            marks = moonPlutoMarks,
                            bgMarks = moonMarsMarks,
                            amber = plutoGrid,
                            timeZoneId = selectedTimezone,
                            ticks = ticksPlu,
                            modifier = Modifier.fillMaxWidth().height(124.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(-60 to "−1h", -5 to "−5m", -1 to "−1m", 1 to "+1m", 5 to "+5m", 60 to "+1h").forEach { (mins, label) ->
                        OutlinedButton(
                            onClick = {
                                onHaptic()
                                isLive = false
                                val newT = inspectedTimeMs + mins * 60_000L
                                centerTimeMs = newT
                                inspectedTimeMs = newT
                            },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 0.dp, vertical = 2.dp),
                            modifier = Modifier.weight(1f).height(38.dp)
                        ) { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Slate100, maxLines = 1, softWrap = false) }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = { onHaptic(); isLive = !isLive },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isLive) Emerald500 else Slate950),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(
                            imageVector = if (isLive) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = null, tint = if (isLive) Slate950 else Slate100, modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isLive) "Live Active" else "Resume Live", fontSize = 12.sp, color = if (isLive) Slate950 else Slate100, fontWeight = FontWeight.Bold)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(
                            onClick = { onHaptic(); zoom = (zoom / 2f).coerceIn(1f, 12f) },
                            shape = RoundedCornerShape(8.dp), contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.size(width = 34.dp, height = 30.dp)
                        ) { Text("−", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Slate100) }
                        Text(
                            text = if (zoom < 10f) "%.1f×".format(zoom) else "%.0f×".format(zoom),
                            fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Slate400,
                            textAlign = TextAlign.Center, modifier = Modifier.width(38.dp)
                        )
                        OutlinedButton(
                            onClick = { onHaptic(); zoom = (zoom * 2f).coerceIn(1f, 12f) },
                            shape = RoundedCornerShape(8.dp), contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.size(width = 34.dp, height = 30.dp)
                        ) { Text("+", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Slate100) }
                    }
                }

                }
            }
        }

        // Mars and its actors (week)
        if (showMarsWeek && marsWeek != null) {
            PlutoWeekCard(
                week = marsWeek, exacts = marsExacts, inspectedTimeMs = inspectedTimeMs, nowMs = nowMs,
                timeZoneId = selectedTimezone, targetName = "Mars", targetGlyph = "♂", onInspectTime = jump
            )
        }

        // Saturn and its actors (week)
        if (showSaturnWeek && saturnWeek != null) {
            PlutoWeekCard(
                week = saturnWeek, exacts = saturnExacts, inspectedTimeMs = inspectedTimeMs, nowMs = nowMs,
                timeZoneId = selectedTimezone, targetName = "Saturn", targetGlyph = "♄", onInspectTime = jump
            )
        }

        // Pluto and its actors (week)
        if (showPlutoWeek && plutoWeek != null) {
            PlutoWeekCard(
                week = plutoWeek, exacts = plutoExacts, inspectedTimeMs = inspectedTimeMs, nowMs = nowMs,
                timeZoneId = selectedTimezone, onInspectTime = jump
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "by A'RA", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
            fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Slate400
        )
        Spacer(modifier = Modifier.height(24.dp))
    }
}

/** v4.0: small labelled switch used for the resonance model options. */
@Composable
private fun ResonanceSwitch(label: String, checked: Boolean, modifier: Modifier = Modifier, onChange: (Boolean) -> Unit) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Emerald500)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(label, fontSize = 11.sp, color = Slate100)
    }
}

/** v4.3: title on the left, current value on the right, used above each sub pane. */
@Composable
private fun PaneHeader(title: String, value: String?, valueColor: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = Slate400,
            modifier = Modifier.weight(1f)
        )
        if (value != null) {
            Text(
                text = value,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = valueColor
            )
        }
    }
}
